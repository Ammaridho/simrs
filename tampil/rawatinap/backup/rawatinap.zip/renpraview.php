<?php 
include "../librari/inc.koneksidb.php"; 
include "header.php";
?>
<html>
<head>
<title>RENCANA KEPERAWATAN</title>
<style type="text/css">
<!--
.style1 {color: #FF0000}
-->
</style>
</head>
<body id="tab3">
RENCANA KEPERAWATAN
  <table align="center" width="100%" border="0" cellpadding="2" cellspacing="1" bgcolor="#CCCCCC">
   <tr bgcolor="#FFFFFF">
      <td width="5%" bgcolor="#D9E8F3"><div align="center"><strong>No</strong></div></td>
      <td width="25%" bgcolor="#D9E8F3"><div align="center"><strong>Diagnosa</strong></div></td>
      <td width="35%" bgcolor="#D9E8F3"><div align="center"><strong>Tujuan</strong></div></td>
      <td width="35%" bgcolor="#D9E8F3"><div align="center"><strong>Intervensi</strong></div></td>
    </tr>
<?php 
	$sql = "SELECT kd_kunjungan,DATE_FORMAT(tanggal_dx,'%d-%m-%Y') AS tanggal_dx, nama_diagnosa,jam_dx, bd FROM dx_keperawatan WHERE kd_kunjungan='$kd_kunjungan' ORDER BY prioritas";
	$qry = mysql_query($sql, $koneksi) 
		 or die ("SQL Error".mysql_error());
	while ($data=mysql_fetch_array($qry)) {
	$no++
?>
    <tr bgcolor="#FFFFFF">
      <td align="center" valign=top><?php echo $no;?></td>
      <td align="left" valign=top><?php echo $data['nama_diagnosa'];?> <?php echo $data['bd'];?></td>

    <td align="left" valign=top><?php
	$nama_diagnosa = $data['nama_diagnosa'];
	$sql1 = "SELECT * FROM dx_keperawatan WHERE kd_kunjungan='$kd_kunjungan' AND nama_diagnosa='$nama_diagnosa'";
    $qry1 = @mysql_query($sql1, $koneksi) or die ("gagal Query");
	while ($data1 =mysql_fetch_array($qry1)) {
	if ($data1[nama_diagnosa]==$nama_diagnosa) {
	echo "Setelah perawatan ".$data1['waktu']." x 24 jam";
	}
	}

	$sql2 = "SELECT * FROM noc WHERE kd_kunjungan='$kd_kunjungan' AND nama_diagnosa='$nama_diagnosa'";
      	$qry2 = @mysql_query($sql2, $koneksi) or die ("gagal Query");
	while ($data2 =mysql_fetch_array($qry2)) {
	if ($data2[nama_diagnosa]==$nama_diagnosa) {
	echo "<ul><li>".$data2['outcome']."</li></ul>";
	}
	}
	?></td>
	<td align="left" valign=top>
	<?php
		$sql3 = "SELECT * FROM nic WHERE kd_kunjungan='$kd_kunjungan' AND nama_diagnosa='$nama_diagnosa'";
      	$qry3 = @mysql_query($sql3, $koneksi) or die ("gagal Query");
	while ($data3 =mysql_fetch_array($qry3)) {
		if ($data3[nama_diagnosa]==$nama_diagnosa) {
	echo "<ul><li>".$data3['intervensi']."</li></ul>";
	}
	}
	?></td>
    </tr>
<?php
}
?>
</table>
</body>
</html>
